(C) Copyright 2019-2020 Muhammad Faran Aiki, All Rights Reserved

DISTRIBUTING TO WORLD, @FSCMD :D

DEVELOPED AS 
 Single Developer (Before 1 January 2020)
 Developed for half year (2019-2020)

MY DEADLINE IS AT 
 1 January 2020, But not 00:00

Started At
 (I Forgot lol, but I'm sure it's 1/2 year before first release)
 *Note that 1/2 year is NOT FULL because I HAVE SCHOOL

Still in development (for programming language and startup) which is really really bad

# Litte Note
 fscmd.py is for global and raw source
  While
 fscmd.exe is for fscmd for windows (this is for Non-Python user)

THIS IS OPEN-SOURCE SOFTWARE, PROGRAM AND PROGRAMMING LANGAUGE. WHOEVER CLAIM/STEAL THIS
PROGRAMMING LANGUAGE SHALL BE PUNISHED. CLAIM/STEAL MEANS THAT MAKE A NEW LICENSE WITHOUT AN
AGREEMENT OF THE CREATOR (MUHAMMAD FARAN AIKI). TO MAKE AN AGREEMENT YOU CAN TEXT ME IN
MY GMAIL BELOW OR CHAT IN REAL TIME

Without Guido Van Rossum, Python. This program will be created using C/Java .etc

This project is 100% Open-Source, which mean you can edit
 all of this Script, Module, PyModule and Folder but 
 please credit me for the basic programming language

fscmd and osfcm or fcm:

fscmd is fast speed command, faran standard command, or fancy style command. osfcm is Open-Source fast speed, fancy style command
 this is the executor of fcm file[s] or command-line
 Heart of the fscmd is None, which mean this is not 
  the real language because of it's open source

fscmd is based on module, but more open (using fscmd itself and python)

fcm is fast command/ faran command
 this is the language that executed by fscmd
 Heart of the fcm is Lexer.py/lexer.py, which mean if you delete
  lexer.py there will be contains error in fscmd

This program is created by a twelve years old, if you claim it, you are the worst :D

"
 I actually on program called ICP [Integrated Coding Pad] but I don't know how to syntax highlight it!
  Can you please show your answer in Youtube/Gmail?
 And I don't know how to fix some problem in FSCMD!
  You can contribute by helping me!
"

FSCMD or FCM or Faran/Fast Command/Fancy Style Command is a new programming language 
 that created using [3] basic programming language:

1. Python [Pure Python 3.7.2]
2. OSFcm/Fcm  [Basic OSFcm Command]
3. Javascript compiled to Python [On working] -> Module: js2py

File Format (Standard/Usual and file format for module ("load" command)):
 *.fcm 

File Format (Unusual and not used for module)
 .fscmd     .fscm 
 .fcmd      .fs   
And other 
 
If you have any issues, like how to counter blindness ...
 You can see at other/counter.txt

For more information, type '?' or 'help' in console
 Because this is important to master the programming language

My:  Youtube : Faran2007 
       Gmail : abang.faran.aiki@gmail.com
   Instagram : faranthemastery
     Discord : Faran2007
   ... (type `help` in fscmd console)

This Version is still
 :: `For` statement still has a bug
 :: Blind at Operator and Separator
 :: File does not have icon

Interactive Programming Language

To run FSCMD,
 Click on the FSCMD.EXE (for windows)
   OR
 Click on the FSCMD.PY (for non-windows that have Python)

** PLEASE NOTE THAT IF YOU DON'T WANNA GET A DEPRESSION OR A STRESS PLEASE DO NOT MODIFY FSCMD LEXER.PY! :) **